namespace NINA.Plugins.Fujifilm.Interop.Native;

public sealed record FujifilmCameraInfo(string ProductName, string SerialNumber, string DeviceId);
